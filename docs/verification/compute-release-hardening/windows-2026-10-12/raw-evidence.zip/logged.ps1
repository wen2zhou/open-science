param([string]$Label,[string]$Program,[string[]]$Arguments)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$evidenceDir=$PSScriptRoot
$sha=(git rev-parse HEAD).Trim()
$log=Join-Path $evidenceDir "$Label.log"
if(Test-Path $log){throw "Refusing to overwrite $log"}
$envRecord=@{}
foreach($key in @('PATH','npm_execpath','ELECTRON_RUN_AS_NODE','COMPUTE_DIAGNOSTIC_DIR','NODE_OPTIONS','RUN_KERNEL','OPEN_SCIENCE_TEST_MAX_WORKERS','VITEST_WINDOWS_FULL_TEST','VITEST_PORTABLE_CI','OPEN_SCIENCE_TEST_PYTHON','RUN_COMPUTE_JOBS','RUN_COMPUTE_CANCELLATION','COMPUTE_TEST_SSH_ALIAS','npm_config_python','GYP_MSVS_VERSION','TEMP','TMP')){$envRecord[$key]=[Environment]::GetEnvironmentVariable($key)}
$start=[DateTime]::UtcNow.ToString('o')
& $Program @Arguments 2>&1 | Tee-Object -FilePath $log
$code=$LASTEXITCODE
@{label=$Label;program=$Program;resolved=(Get-Command $Program).Source;arguments=$Arguments;exitCode=$code;sha=$sha;cwd=(Get-Location).Path;environment=$envRecord;start=$start;end=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 6 -Compress | Add-Content (Join-Path $evidenceDir 'commands.jsonl')
exit $code

import fs from 'node:fs';import path from 'node:path';
const dir=process.argv[2],r=JSON.parse(fs.readFileSync(path.join(dir,'reconciliation.json'),'utf8'));
const reason={
'compute-environment.test.ts':['process.platform === win32','Unix shell source/environment execution',58],
'job-deletion-owner.test.ts':['process.platform === win32','Unix shell remote-directory cleanup protocol',333],
'job-dispatcher.test.ts':['pit = it.skipIf(process.platform === win32)','Unix launcher shell execution',15],
'remote-job-process.test.ts':['describe.skipIf(process.platform === win32)','Unix process session termination shell',25],
'ssh-runner.test.ts':['pit = it.skipIf(process.platform === win32)','Unix executable/signal/shell fixture',10],
'job-recovery-regressions.integration.test.ts':['process.platform === win32','Unix shell remote launch/path/permission fixture',111],
'compute-probe-script.test.ts':['describe.skipIf(process.platform === win32)','Unix probe shell protocol',13],
'job-deletion-runtime-drain.test.ts':['process.platform === win32','Unix shell cleanup fixture for both historical workdirs',49],
'connection-broker.test.ts':['it.runIf(platform() !== win32)','Unix multiplexing socket directory lifecycle',124],
'archive.test.ts':['process.platform === win32','256 GiB sparse archive guard fixture',202]
};
const out=[];for(const group of ['package','host','consumer'])for(const s of r[group].skips){let v=reason[path.basename(s.file)];if(path.basename(s.file)==='compute-remote-operation-owner.test.ts')v=s.name.includes('BSD')?['process.platform === darwin','Native BSD find/stat fallback',s.name.includes('downloads')?1040:578]:['process.platform === darwin || process.platform === linux','Unix native find/stat/filename fixture',s.name.includes('filenames')?543:513];out.push({group,...s,guard:v[0],reason:v[1],sourceLine:v[2]})}fs.writeFileSync(path.join(dir,'skips-explained.json'),JSON.stringify(out,null,2));console.log({total:out.length,package:r.package.skips.length,host:r.host.skips.length,consumer:r.consumer.skips.length});

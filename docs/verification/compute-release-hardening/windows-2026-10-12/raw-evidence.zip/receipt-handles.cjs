const fs=require('node:fs'),path=require('node:path');
if(process.argv.some(x=>x.endsWith('file_evidence_worker.js'))){
 const out=path.join(process.env.COMPUTE_DIAGNOSTIC_DIR,'receipt-handles.jsonl');const opened=new Map();
 const open=fs.openSync,close=fs.closeSync,rename=fs.renameSync;
 fs.openSync=function(p,...args){const fd=open(p,...args);opened.set(fd,{path:path.resolve(p),flags:args[0]});return fd};
 fs.closeSync=function(fd){const result=close(fd);opened.delete(fd);return result};
 let input='';process.stdin.on('data',chunk=>input+=chunk.toString());
 fs.renameSync=function(a,b){try{return rename(a,b)}catch(e){fs.appendFileSync(out,JSON.stringify({code:e.code,source:path.resolve(a),target:path.resolve(b),opened:[...opened.values()],request:input,cwd:process.cwd()})+'\n');throw e}};
}

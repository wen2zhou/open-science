const fs=require('node:fs');
const path=require('node:path');
if(process.argv.some(x=>x.endsWith('file_evidence_worker.js'))){
 const target=path.join(process.env.COMPUTE_DIAGNOSTIC_DIR,'receipt-probe.jsonl');
 const rename=fs.renameSync;
 const metadata=p=>{try{const s=fs.lstatSync(p);return {path:path.resolve(p),mode:s.mode,ino:s.ino,size:s.size,nlink:s.nlink,mtime:s.mtimeMs}}catch(e){return {code:e.code}}};
 fs.appendFileSync(target,JSON.stringify({event:'worker',argv:process.argv,cwd:process.cwd()})+'\n');
 fs.renameSync=function(a,b){try{return rename(a,b)}catch(e){fs.appendFileSync(target,JSON.stringify({event:'rename-error',code:e.code,stack:e.stack,source:metadata(a),target:metadata(b)})+'\n');throw e}};
}

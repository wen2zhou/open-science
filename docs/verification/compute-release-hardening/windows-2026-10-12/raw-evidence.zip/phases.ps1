param([ValidateSet('prepare','package','host','consumer','impact')][string]$Phase)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
function Run([string]$Label,[string]$Program,[string[]]$ArgumentList){
 & (Join-Path $PSScriptRoot 'logged.ps1') -Label $Label -Program $Program -Arguments $ArgumentList
 if($LASTEXITCODE -ne 0){throw "$Label failed: $LASTEXITCODE"}
}
switch($Phase){
 'prepare'{
 Run 'build-packages' 'npm.cmd' @('run','build:packages')
 Run 'prisma-check' 'node' @('scripts/check-prisma-client.mjs')
 Run 'native-resolution' 'node' @('-e',"for (const p of ['@aipoch/compute/node','@aipoch/process-tree-native','@aipoch/safe-file-publisher-native']) { console.log(p, require.resolve(p)); require(p) }")
 }
 'package'{
 Run 'build-compute' 'npm.cmd' @('run','build:compute')
 Run 'package-types' 'npm.cmd' @('--prefix','packages/compute','run','typecheck')
 Run 'package-tests' 'npm.cmd' @('--prefix','packages/compute','test','--','--reporter=default','--reporter=json',"--outputFile.json=$PSScriptRoot/package-results.json")
 Run 'package-isolation' 'npm.cmd' @('run','check:compute-package')
 Run 'node-types' 'npm.cmd' @('run','typecheck:node:compiled')
 Run 'web-types' 'npm.cmd' @('run','typecheck:web:compiled')
 }
 {$_ -in 'host','consumer'}{
 $env:RUN_KERNEL='1'
 $env:OPEN_SCIENCE_TEST_MAX_WORKERS='1'
 $env:VITEST_WINDOWS_FULL_TEST='1'
 $env:OPEN_SCIENCE_TEST_PYTHON='C:/Program Files/Python312/python.exe'
 Remove-Item Env:VITEST_PORTABLE_CI -ErrorAction SilentlyContinue
 $files=@(Get-Content "docs/verification/compute-release-hardening/$Phase-tests.json" -Raw | ConvertFrom-Json)
 Run "$Phase-tests" 'node' (@('node_modules/vitest/vitest.mjs','run','--project','default','--project','process','--project','architecture','--project','database','--maxWorkers=1','--testTimeout=60000','--hookTimeout=60000')+$files+@('--reporter=default','--reporter=json',"--outputFile.json=$PSScriptRoot/$Phase-results.json"))
 }
 'impact'{
 Run 'impact-selection' 'node' @('scripts/ci/module-test-impact.mjs','affected','--base','7bd0e4c6395f2b6cc4ed896bb233641ead79d6d1','--head',(git rev-parse HEAD).Trim(),'--explain')
 Run 'impact-tests' 'node' @('node_modules/vitest/vitest.mjs','run','--project','default','scripts/ci/check-module-ownership.test.ts','scripts/ci/module-test-impact.test.ts','scripts/ci/validate-module-impact.test.ts','scripts/ci/package-test-impact.test.ts','scripts/ci/package-host-test-impact.test.ts')
 }
}

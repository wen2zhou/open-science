import fs from 'node:fs';import path from 'node:path';import {execFileSync} from 'node:child_process';
const base='7bd0e4c6395f2b6cc4ed896bb233641ead79d6d1',initial='387f1e3044845f187b3e4f958014d73c2842df5c';
const paths=['src/main/notebook/host-compute.integration.test.ts','src/main/session-persistence/compute-policy.test.ts'];
const result=paths.map(file=>{const a=execFileSync('git',['show',`${base}:${file}`],{encoding:'utf8'}),b=execFileSync('git',['show',`${initial}:${file}`],{encoding:'utf8'});const line=a.split('\n').findIndex(x=>file.includes('host-compute')?x.includes('mcpRpcEndpoint: stub.endpoint'):x.includes('await symlink(outside, path)'));return {file,base,initial,identicalAtBaseAndInitial:a===b,baseExcerpt:a.split('\n').slice(Math.max(0,line-2),line+4).join('\n'),baseLine:line+1}});
fs.writeFileSync(path.join(process.argv[2],'baseline-fixture-comparison.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));

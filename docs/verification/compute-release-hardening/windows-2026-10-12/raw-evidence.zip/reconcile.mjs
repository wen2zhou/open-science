import fs from 'node:fs';
import path from 'node:path';
const evidence=process.argv[2];
const root=process.cwd().replaceAll('\\','/').toLowerCase();
const output={};
for(const group of ['package','host','consumer']){
 const file=path.join(evidence,group+'-results.json');
 if(!fs.existsSync(file))continue;
 const results=JSON.parse(fs.readFileSync(file,'utf8'));
 const actual=results.testResults.map(x=>x.name.replaceAll('\\','/').toLowerCase().replace(root+'/',''));
 const expected=group==='package'?null:JSON.parse(fs.readFileSync(`docs/verification/compute-release-hardening/${group}-tests.json`,'utf8')).map(x=>x.toLowerCase());
 output[group]={files:actual.length,passed:results.numPassedTests,failed:results.numFailedTests,pending:results.numPendingTests,missing:expected?.filter(x=>!actual.includes(x)),unexpected:expected?actual.filter(x=>!expected.includes(x)):[],skips:results.testResults.flatMap(f=>f.assertionResults.filter(t=>['pending','skipped','todo'].includes(t.status)).map(t=>({file:f.name,name:t.fullName,status:t.status}))),failures:results.testResults.flatMap(f=>f.assertionResults.filter(t=>t.status==='failed').map(t=>({file:f.name,name:t.fullName,messages:t.failureMessages})))};
}
const required=JSON.parse(fs.readFileSync('docs/verification/compute-release-hardening/windows-required-cases.json','utf8'));
output.windowsRequired=required.flatMap(f=>f.tests.map(name=>{
 for(const group of ['host','consumer']){
 const file=path.join(evidence,group+'-results.json');if(!fs.existsSync(file))continue;
 const results=JSON.parse(fs.readFileSync(file,'utf8'));
 const suite=results.testResults.find(x=>x.name.replaceAll('\\','/').toLowerCase().endsWith(f.file.toLowerCase()));
 const test=suite?.assertionResults.find(t=>t.fullName===name);if(test)return {file:f.file,name,status:test.status};
 }return {file:f.file,name,status:'not-found'};
}));
fs.writeFileSync(path.join(evidence,'reconciliation.json'),JSON.stringify(output,null,2));
console.log(JSON.stringify(output,null,2));

const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'compute-filesystem-probe-'));
try {
 const source=path.join(root,'source');fs.writeFileSync(source,'source');
 try{fs.symlinkSync(source,path.join(root,'link'));console.log('file symlink: passed')}catch(e){console.log('file symlink:',e.code)}
 let failed=0;
 for(let i=0;i<100;i++){
  const a=path.join(root,'a'+i),b=path.join(root,'b'+i),c=path.join(root,'c'+i);
  fs.writeFileSync(a,'old');fs.linkSync(a,b);fs.rmSync(a);fs.writeFileSync(c,'new');
  try{fs.renameSync(c,b)}catch(e){failed++;console.log('hardlink unlink replace',i,e.code)}
 }
 console.log({root,iterations:100,failed});
}finally{fs.rmSync(root,{recursive:true,force:true})}

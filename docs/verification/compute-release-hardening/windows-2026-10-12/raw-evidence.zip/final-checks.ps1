$ErrorActionPreference='Stop'
function Run([string]$Label,[string]$Program,[string[]]$ArgumentList){
 & (Join-Path $PSScriptRoot 'logged.ps1') -Label $Label -Program $Program -Arguments $ArgumentList
 if($LASTEXITCODE -ne 0){throw "$Label failed $LASTEXITCODE"}
}
$env:PATH='D:/Programs/Git/bin;'+$env:PATH
$env:npm_execpath='C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js'
Run 'impact-selection-fixed-sha' 'node' @('scripts/ci/module-test-impact.mjs','affected','--base','7bd0e4c6395f2b6cc4ed896bb233641ead79d6d1','--head',(git rev-parse HEAD).Trim(),'--explain')
Run 'impact-tests-fixed-sha' 'node' @('node_modules/vitest/vitest.mjs','run','--project','default','scripts/ci/check-module-ownership.test.ts','scripts/ci/module-test-impact.test.ts','scripts/ci/validate-module-impact.test.ts','scripts/ci/package-test-impact.test.ts','scripts/ci/package-host-test-impact.test.ts')
Run 'node-types-fixed-sha' 'npm.cmd' @('run','typecheck:node:compiled')
Run 'web-types-fixed-sha' 'npm.cmd' @('run','typecheck:web:compiled')
Run 'lint-fixed-sha' 'npm.cmd' @('run','lint')
Run 'format-fixed-sha' 'node' @('node_modules/prettier/bin/prettier.cjs','--check','src/main/notebook/host-compute.integration.test.ts')
